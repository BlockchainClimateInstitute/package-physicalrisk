This is a physical climate value at risk model for real estate asset and portfolio in the UK. It covers all domestic and non-domestic properties with EPC certificates.
